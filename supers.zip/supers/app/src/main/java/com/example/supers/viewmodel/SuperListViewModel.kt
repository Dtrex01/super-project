package com.example.supers.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.supers.database.DatabaseSuperId
import com.example.supers.repository.SupersRepository
import com.example.supers.util.networkutils.LoadingState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.lang.Exception

class SuperListViewModel (private val supersRepository: SupersRepository) : ViewModel() {

    private val _loadingState = MutableLiveData<LoadingState>()
    val loadingState: LiveData<LoadingState>
        get() = _loadingState

    /**
     * This is the job for all coroutines started by this ViewModel.
     */
    private val viewModelJob = SupervisorJob()

    /**
     * This is the main scope for all coroutines launched by MainViewModel.
     */
    private val viewModelScope = CoroutineScope(viewModelJob + Dispatchers.Main)

    /**
     * init{} is called immediately when this ViewModel is created.
     */
    init {
        refreshDataFromRepository()
    }


    /**
     * Refresh data from the repository. Use a coroutine launch to run in a background thread.
     */
    fun refreshDataFromRepository() {
        viewModelScope.launch {

            try {
                _loadingState.value = LoadingState.LOADING
                supersRepository.refreshSuper()
                _loadingState.value = LoadingState.LOADED

            } catch (networkError: Exception) {
                _loadingState.value = LoadingState.error(networkError.message)
            }
        }
    }

    /**
     * Cancel all coroutines when the ViewModel is cleared
     */
    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }

    //for display data in second fragment
    // LiveData to handle navigation to the selected Character
    private val _navigateToSelectedProperty = MutableLiveData<DatabaseSuperId>()
    val navigateToSelectedProperty: LiveData<DatabaseSuperId>
        get() = _navigateToSelectedProperty

    /**
     * When the character is clicked, set the [_navigateToSelectedProperty] [MutableLiveData]
     * @param characterProperty The [Character] that was clicked on.
     */

    fun displayPropertyDetails(superProperty: DatabaseSuperId) {
        _navigateToSelectedProperty.value = superProperty
    }

    /**
     * After the navigation has taken place, make sure navigateToSelectedProperty is set to null
     */
    fun displayPropertyDetailsComplete() {
        _navigateToSelectedProperty.value = null
    }


    /**
     * For Search feature based on entered text
     */
    lateinit var allItemsSearch: LiveData<List<DatabaseSuperId>>
    var search = MutableLiveData<String>("%")

    init {
        allItemsSearch = Transformations.switchMap(search) { search ->
            supersRepository.getItemsSearch(search)

        }
    }

    // set the filter for allItemsFiltered
    fun setSearch(newSearch: String) {
        // optional: add wildcards to the filter
        val f = when {
            newSearch.isEmpty() -> "%"
            else -> "%$newSearch%"
        }
        search.postValue(f)
    }

    /**
     * For Filter Feature based on Appearance
     */
    lateinit var allItemsFiltered: LiveData<List<DatabaseSuperId>>
    var filter = MutableLiveData<String>("%")

    init {
        allItemsFiltered = Transformations.switchMap(filter) { filter ->
            supersRepository.getItemsByAppearance(filter)
        }
    }

    // set the filter for allItemsFiltered
    fun setFilter(newFilter: Int) {
        val f:String = when{
            newFilter == null -> "%"
            else -> "%$newFilter%"
        }
        filter.postValue(f)
    }

}