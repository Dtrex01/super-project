package com.example.supers.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.supers.database.DatabaseSuperId

class SuperDetailViewModel: ViewModel(){

    // The internal MutableLiveData for the selected character
    private val _selectedProperty = MutableLiveData<DatabaseSuperId>()

    // The external LiveData for the SelectedCharacter
    val selectedProperty: LiveData<DatabaseSuperId>
        get() = _selectedProperty


    fun setProperty(characterProperty: DatabaseSuperId){
        _selectedProperty.value = characterProperty
    }

}
