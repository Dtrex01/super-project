package com.example.supers.di

import com.example.supers.viewmodel.SuperDetailViewModel
import com.example.supers.viewmodel.SuperListViewModel
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val viewModelModule = module {
    viewModel { SuperListViewModel(get()) }

    viewModel { SuperDetailViewModel() }
}
