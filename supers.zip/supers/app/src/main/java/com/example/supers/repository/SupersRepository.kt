package com.example.supers.repository

import androidx.lifecycle.LiveData
import com.example.supers.database.DatabaseSuperId
import com.example.supers.database.SuperIdDatabase
import com.example.supers.network.Super_APIServices
import com.example.supers.util.OpenForTesting
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber

@OpenForTesting.OpenForTesting
class SupersRepository (private val superApiservices: Super_APIServices, private val database: SuperIdDatabase) {
    suspend fun refreshSuper() {
        withContext(Dispatchers.IO) {
            Timber.d("refresh supers is called");
            val superList = superApiservices.getSuperList().await()
            database.superIdDao.insertAll(superList)
        }
    }

    //function for Search
    fun getItemsSearch(filter: String): LiveData<List<DatabaseSuperId>> {
        return database.superIdDao.getAll(filter)
    }

   /* //function for filter based on appearance
    fun getItemsByAppearance(season: String): LiveData<List<DatabaseSuperId>> {
        return database.superIdDao.getLocalDBSuperId()ByName(season)
    }*/
}