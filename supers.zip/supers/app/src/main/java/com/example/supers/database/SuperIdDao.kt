package com.example.supers.database

import androidx.databinding.adapters.Converters
import androidx.lifecycle.LiveData
import androidx.room.*



@Dao
interface SuperIdDao {
    /**
     * Insert data from API response
     *
     * When a new network result is received,
     * update the local database and display the new content on the screen from the local database.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(superId : List<DatabaseSuperId>)


    /**
     * Instead, display data that you fetch from the database.
     */
    @Query("SELECT * FROM DatabaseSuperId")
    fun getLocalDBSuperId(): LiveData<List<DatabaseSuperId>>

    @Query("select * from DatabaseSuperId order by id ASC")
    fun getAllSupers(): LiveData<List<DatabaseSuperId>>
    @Update
    fun update(DatabaseSuperId: DatabaseSuperId)

}


@Database(entities = [DatabaseSuperId::class], version  = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class SuperIdDatabase: RoomDatabase(){
    abstract val superIdDao: SuperIdDao
}