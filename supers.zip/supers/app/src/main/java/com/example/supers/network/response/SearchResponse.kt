package com.example.supers.network.response

import com.example.supers.database.DatabaseSuperId
import com.google.gson.annotations.SerializedName


data class SearchResponse(
    val response: String,
    val results: List<DatabaseSuperId>,
    @SerializedName("results-for")
    val resultsFor: String
)