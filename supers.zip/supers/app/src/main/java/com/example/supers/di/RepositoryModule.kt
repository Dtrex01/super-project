package com.example.supers.di

import com.example.supers.database.SuperIdDatabase
import com.example.supers.network.Super_APIServices
import com.example.supers.repository.SupersRepository
import org.koin.dsl.module

val repositoryModule= module {
    fun provideRepository(api: Super_APIServices, dao: SuperIdDatabase): SupersRepository {
        return SupersRepository(api, dao)
    }

    single { provideRepository(get(), get())
    }
}