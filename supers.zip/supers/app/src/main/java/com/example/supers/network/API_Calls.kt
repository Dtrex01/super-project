package com.example.supers.network

object API_Calls {
    const val API_BASE_URL= "https://superheroapi.com/api/10217553111446777/"
    const val API_SUPER_LIST= "644"
}