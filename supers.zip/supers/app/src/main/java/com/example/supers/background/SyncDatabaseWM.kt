package com.example.supers.background

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.supers.repository.SupersRepository
import org.koin.core.KoinComponent
import org.koin.core.inject
import timber.log.Timber

class SyncDatabaseWM (appContext: Context, params: WorkerParameters): CoroutineWorker(appContext, params),
    KoinComponent {

    val dataSyncRepository: SupersRepository by inject()

    companion object{
        const val WORK_NAME="com.example.supers.background.SyncDatabaseWM"
    }
    override suspend fun doWork(): Result {
        /**
         * Sync the backend API data with local database even if user is not using the app or device restarts
         */
        try{
            dataSyncRepository.refreshSuper();
            Timber.d("WorkManager: sync in progress")
        }
        catch (e:Exception){
            Timber.e("WorkManager error: ${e.localizedMessage}")
            return Result.retry()
        }
        return Result.success()
    }
}