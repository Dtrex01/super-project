package com.example.supers.viewadapters

import android.widget.ImageView
import com.bumptech.glide.Glide

import androidx.databinding.BindingAdapter


@BindingAdapter("imageUrl")
fun setImageUrl(imageView: ImageView, url: String) {
    Glide.with(imageView.context).load(url).into(imageView)
}