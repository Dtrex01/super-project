package com.example.supers.viewadapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.supers.R
import com.example.supers.database.DatabaseSuperId
import com.example.supers.databinding.RowSuperBinding


class SupersAdapter (val callback: SuperClick): RecyclerView.Adapter<SuperViewHolder>(){

    /**
     * The characters that our Adapter will show
     */
    var results: List<DatabaseSuperId> = emptyList()
    set(value) {
        field = value
        // Notify any registered observers that the data set has changed. This will cause every
        // element in our RecyclerView to be invalidated.
        notifyDataSetChanged()
    }

    /**
     * Called when RecyclerView needs a new {@link ViewHolder} of the given type to represent
     * an item.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SuperViewHolder {
        val withDataBinding: RowSuperBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            SuperViewHolder.LAYOUT,
            parent,
            false
        )
        return SuperViewHolder(withDataBinding)
    }

    override fun getItemCount() = results.size

    /**
     * Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the {@link ViewHolder#itemView} to reflect the item at the given
     * position.
     */
    override fun onBindViewHolder(holder: SuperViewHolder, position: Int) {

        holder.viewDataBinding.also {
            it.results = results[position]
            //To handle onclick
            it.resultsCallback = callback

        }
    }
}
/**
 * ViewHolder for character items. All work is done by data binding.
 */
class SuperViewHolder(val viewDataBinding: RowSuperBinding) :
    RecyclerView.ViewHolder(viewDataBinding.root) {
    companion object {
        @LayoutRes
        val LAYOUT = R.layout.row_super
    }
}

/**
 * Click listener for Character. By giving the block a name it helps a reader understand what it does.
 *
 */
class SuperClick(val block: (DatabaseSuperId) -> Unit) {
    /**
     * Called when a character is clicked
     *
     * @param character the character that was clicked
     */
    fun onClick(superId: DatabaseSuperId) = block(superId)
}
