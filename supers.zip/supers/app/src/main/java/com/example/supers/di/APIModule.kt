package com.example.supers.di

import com.example.supers.network.Super_APIServices
import org.koin.dsl.module
import retrofit2.Retrofit

val apiModule = module {
    fun provideUserApi(retrofit: Retrofit): Super_APIServices {
        return retrofit.create(Super_APIServices::class.java)
    }

    single { provideUserApi(get()) }
}