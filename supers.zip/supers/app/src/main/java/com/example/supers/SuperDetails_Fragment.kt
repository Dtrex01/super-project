package com.example.supers

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v4.media.session.MediaSessionCompat.Token.fromBundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.core.app.Person.fromBundle
import androidx.fragment.app.Fragment
import androidx.media.AudioAttributesCompat.fromBundle
import com.example.supers.databinding.FragmentSuperdetailBinding
import com.example.supers.viewmodel.SuperDetailViewModel
import org.koin.android.viewmodel.ext.android.viewModel

class SuperDetails_Fragment: Fragment(){

    val viewModel by viewModel<SuperDetailViewModel>()

    @SuppressLint("UseRequireInsteadOfGet")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val binding = FragmentSuperdetailBinding.inflate(inflater)
        binding.setLifecycleOwner(this)
        val superProperty = SuperDetails_Fragment.fromBundle(arguments!!).selectedProperty
        binding.viewModel = viewModel
        viewModel.setProperty(superProperty)

        return binding.root

    }
}