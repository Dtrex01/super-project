package com.example.supers.network

import com.example.supers.database.DatabaseSuperId
import com.example.supers.network.response.SearchResponse
import kotlinx.coroutines.Deferred
import retrofit2.http.GET
import retrofit2.http.Path

interface Super_APIServices {

    @GET(API_Calls.API_SUPER_LIST)
    fun getSuperList(): Deferred<List<DatabaseSuperId>>

    @GET("search/{search}")
    fun DatabaseSuperId(@Path("search") search: String) : SearchResponse



}


