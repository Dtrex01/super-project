package com.example.supers.database

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity

data class DatabaseSuperId(

@PrimaryKey
        var id: Int,
        var name: String,
        var powerstats: String,
        var biography: String,
        var work: String,
        var image: List<String>
    ): Parcelable {}

